package com.example.bus

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.coroutineScope
import androidx.navigation.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.bus.databinding.FragmentBusScheduleBinding
import com.example.bus.model.ScheduleViewModel
import com.example.bus.model.ScheduleViewModelFactory
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch


class BusSchedule : Fragment() {

    private var _binding: FragmentBusScheduleBinding? = null

    private val binding get() = _binding!!

    private lateinit var recyclerView: RecyclerView
    private val viewModel: ScheduleViewModel by activityViewModels {
        ScheduleViewModelFactory(
            (activity?.application as BusScheduleApplication).database.scheduleDao()
                )
    }
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentBusScheduleBinding.inflate(inflater, container, false)
        val view = binding.root
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        recyclerView = binding.recyclerView
        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        val busStopAdapter = BusStopAdapter { val action =
                BusScheduleDirections.actionBusScheduleToStopSchedule(stopName = it.stopName)
            view.findNavController().navigate(action)
        }

        recyclerView.adapter = busStopAdapter
        lifecycle.coroutineScope.launch {
            viewModel.fullSchedule().collect() {
                busStopAdapter.submitList(it)
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }


}



